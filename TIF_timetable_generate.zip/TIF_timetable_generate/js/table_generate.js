function pageload() {
    const element = document.querySelector("#tif_table");

    // time_axis追加
    element.insertAdjacentElement("beforeend", time_axis_add());

    // stage追加
    element.insertAdjacentElement("beforeend", stage_add());


    stage_detail_add();

    group_list_add();

    css_customize();
}

const max_i = (time_to_minute(timetable_end) - time_to_minute(timetable_start))
/ (time_to_minute(timetable_one_square)) + 1;


function time_axis_add() {

    // <div class="time_axis time_axis_origin">
    //     <div class="time_axis_adjustment">
    //         <div class="time_axis_param" style="top: 0px;">09:30</div>
    //     </div>
    // </div>
    let time_axis = document.createElement('div');
    time_axis.classList.add("time_axis", "time_axis_origin");

    let time_axis_adjustment = document.createElement('div');
    time_axis_adjustment.classList.add("time_axis_adjustment");
    time_axis.setAttribute("id", "time_axis");



    for (let i = 0; i < max_i; i++) {
        let add_element = document.createElement('div');
        add_element.classList.add("time_axis_param");
        add_element.style.top = String(i * one_square * time_to_minute(timetable_one_square) / time_to_minute(one_square_time)) + "px";
        add_element.textContent = minute_to_time(time_to_minute(timetable_start)
            + i * time_to_minute(timetable_one_square));

        time_axis_adjustment.insertAdjacentElement("beforeend", add_element);

    }
    time_axis.insertAdjacentElement("beforeend", time_axis_adjustment);
    return time_axis;

}

function stage_add() {
    let stage_all_elm = document.createElement('div');
    stage_all_elm.classList.add("stage_list", "col");

    for (let stage_id in stage_list) {
        let stage_elm = document.createElement('div');
        stage_elm.setAttribute("id", stage_id);
        stage_elm.classList.add("stage", "col");
        stage_elm.style.backgroundColor = stage_list[stage_id]["color"];
        stage_all_elm.insertAdjacentElement("beforeend", stage_elm);
    }

    return stage_all_elm;
}

function stage_detail_add() {
    for (let stage_id in stage_list) {
        // stage_detailをつくる
        let stage_detail = document.createElement('div');
        stage_detail.classList.add("stage_detail");

        // stage_picをつくる
        let stage_pic = document.createElement('div');
        stage_pic.classList.add("stage_pic")

        let img = document.createElement("img")
        img.src = stage_list[stage_id]["stage_pic"]

        img.style.width = "90%";

        stage_pic.insertAdjacentElement("beforeend", img)
        stage_detail.insertAdjacentElement("beforeend", stage_pic)

        // stage_name をつくる
        let stage_name = document.createElement("div")
        stage_name.classList.add("stage_name")

        let add_html = '<div class="group_detail"><div class="group_name">'
            + stage_list[stage_id]["stage_name"] + '</div></div></div>'
        stage_name.insertAdjacentHTML("beforeend", add_html)
        stage_detail.insertAdjacentElement("beforeend", stage_name)

        // stage_place をつくる
        let stage_place = document.createElement("div")
        stage_place.classList.add("stage_place")

        add_html = '<div class="group_detail"><div class="group_name" style="font-size:14px;">'
            + stage_list[stage_id]["stage_place"] + '</div></div></div>'
        stage_place.insertAdjacentHTML("beforeend", add_html)
        stage_detail.insertAdjacentElement("beforeend", stage_place)


        add_html = '<div class="clear_block"></div>'
        stage_detail.insertAdjacentHTML("beforeend", add_html)

        // stage_detail を追加する
        document.querySelector("#" + stage_id).insertAdjacentElement("beforeend", stage_detail)


    }
}

function group_list_add() {

    for (let stage_id in stage_list) {
        let group_list = document.createElement('div');
        group_list.classList.add("group_list");

        let time_scales = document.createElement('div');
        time_scales.classList.add("time_scales")
        for (let i = 0; i < max_i; i++) {
            let time_scale = document.createElement('div');
            time_scale.classList.add("time_scale");
            time_scale.style.top = String(i * one_square * time_to_minute(timetable_one_square) / time_to_minute(one_square_time)) + "px";

            time_scales.insertAdjacentElement("beforeend", time_scale);

        }
        document.querySelector("#" + stage_id).insertAdjacentElement("beforeend", time_scales);

        document.querySelector("#" + stage_id).insertAdjacentElement("beforeend", group_list);
    }


    for (var group_detail_json of group_list) {
        let group = document.createElement('div');
        group.classList.add("group");
        group.onclick = check_group;


        let icons_list = ["is_shooting", "is_premium"]

        let icons_span = document.createElement('span');
        icons_span.classList.add("p_in_icons")
        for (let is_icons of icons_list) {
            if (group_detail_json[is_icons]) {
                icons_span.insertAdjacentHTML("beforeend", '<span class= "' + is_icons + '">')
            }
        }

        group.insertAdjacentElement("beforeend", icons_span)

        let add_html = '<div class="group_detail">'
            + '<div class="group_name">'
            + group_detail_json["group_name"]
            + '</div>'
            + '<div class="group_time">'
            + group_detail_json["start_time"] + "~" + group_detail_json["end_time"]
            + '</div>' + '</div>';


        group.insertAdjacentHTML("beforeend", add_html);

        let group_size_list = group_size_calc(group_detail_json);
        group.style.top = String(group_size_list[0]) + "px";
        group.style.height = String(group_size_list[1]) + "px";

        document.querySelector("#" + group_detail_json["stage_id"] + " > div.group_list")
            .insertAdjacentElement("beforeend", group);

    }

}

