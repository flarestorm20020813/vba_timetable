/*
* 時刻表記⇒時刻(分)　03:30⇒210分
====================================================*/
function time_to_minute(time_str) {
    const minute_list = [60, 1]
    let time_list = time_str.split(":")

    result = 0;
    for (i = 0; i < time_list.length; i++) {
        result = result + time_list[i] * minute_list[i];
    }

    return result;
}

/*
* 時刻(分)⇒時刻表記　210分⇒03:30
====================================================*/
function minute_to_time(minute) {
    let result = (Math.floor(minute / 60) % 100).toString().padStart(2, '0') + ":" + Math.floor(minute % 60).toString().padStart(2, '0')
    return result;
}

/*
* top と heightを計算
====================================================*/
function group_size_calc(group_detail_json) {

    let top = one_square * (time_to_minute(group_detail_json["start_time"]) - time_to_minute(timetable_start)) / time_to_minute(one_square_time) + group_margin;
    let height = one_square * (time_to_minute(group_detail_json["end_time"]) - time_to_minute(group_detail_json["start_time"])) / time_to_minute(one_square_time) - group_margin * 2;

    return [top, height];
}

/*
* css のカスタマイズ
====================================================*/
function css_customize() {
    var stage_detail = document.querySelector("#hot_stage > div.stage_detail").getBoundingClientRect();

    var time_y = document.querySelector("#time_axis > div > div:nth-child(1)");
    var fontsize = Number((window.getComputedStyle(time_y, '').fontSize).replace("px", ""));

    document.querySelector("#time_axis").style.top = String(stage_detail.height - fontsize / 2) + "px";
    document.querySelector("#tif_table").style.height = String(stage_detail.height 
        + one_square * (time_to_minute(timetable_end) - time_to_minute(timetable_start) +5) 
        / time_to_minute(one_square_time)) + "px";

}

/*
* グループを観る
====================================================*/
function check_group() {
    let add_element = document.createElement('div');
    add_element.classList.add("check_group");
    let flg = "kakutei"
    add_element.value = flg;

    if (this.querySelector("div.check_group") == null) {
        this.querySelector("div").insertAdjacentElement("beforeend", add_element);
    }
    else if (this.querySelector("div.check_group").value == flg) {
        this.querySelector("div.check_group").remove();
        add_element.value = "kari";
        add_element.style.backgroundColor = "transparent";
        add_element.style.borderColor = "#000000";
        add_element.style.opacity = 1;
        this.querySelector("div").insertAdjacentElement("beforeend", add_element);
    }
    else {
        this.querySelector("div.check_group").remove();
    }
}
