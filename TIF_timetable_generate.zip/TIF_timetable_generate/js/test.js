function test() {
    const a = document.querySelector("body > div");
    const items = a.children;

    let text = "";
    for (let i = 0; i < items.length; i++) {

        let stage = items[i].querySelector("div.p-timetable__table-head > div.p-in-stage");

        const groups = items[i].querySelector("div.p-timetable__table-schedule").children;
        for (let j = 0; j < groups.length; j++) {
            console.log(groups[j]);
            let group_time = groups[j].querySelector("div > p.p-in-time")
            let group_name = groups[j].querySelector("div > p.p-in-title")
            
            let group_photo = groups[j].querySelector("span > span.p-in-icon.is-shooting")
            let group_premier = groups[j].querySelector("span > span.p-in-icon.is-premium")

            let list = [stage, group_name, group_time, group_photo, group_premier]



            var list_text = []
            for (var column of list) {
                if (column == null) {
                    list_text.push('FALSE')
                } else {

                    list_text.push('"' + column.innerHTML + '"')
                }
            }

            text = text +  list_text.join(',') + "\r\n";
        }
    }
    console.log(text);
}